import React from "react";
import { useHistory } from "react-router-dom";
// import { Table } from "monday-ui-react-core/";

const OrdersBoard = () => {
    const history = useHistory();
    const homepage = () => (
        history.push("/")
    )

    const columns = [{
        id: "item",
        title: "Item",
        width: 180,
        loadingStateType: "medium-text"
      }, {
        id: "salesAssociate",
        title: "Sales Associate",
        width: 200,
        loadingStateType: "long-text"
      }, {
        id: "scentProfiles",
        title: "Scent Profiles",
        width: 200,
        loadingStateType: "medium-text"
      }];

    return (
        <>
            Hello
        </>
    );
};

export default OrdersBoard