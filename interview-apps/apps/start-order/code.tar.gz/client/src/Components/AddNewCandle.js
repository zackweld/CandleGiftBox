import React from "react";
import { useState, useEffect, useMemo } from "react";
import ".././App.css";
import mondaySdk from "monday-sdk-js";
import "monday-ui-react-core/dist/main.css";
//Explore more Monday React Components here: https://style.monday.com/
// import AttentionBox from "monday-ui-react-core/dist/AttentionBox.js";
import { Flex, Dropdown, TextField, Button } from "monday-ui-react-core";
import { useHistory } from "react-router-dom";
import axios from "axios";

// Usage of mondaySDK example, for more information visit here: https://developer.monday.com/apps/docs/introduction-to-the-sdk/
const monday = mondaySdk();

const AddNewCandle = () => {
//   const options = useMemo(
//     () => [
//       {
//         value: "Rotem",
//         label: "Rotem Dekel"
//       },
//       {
//         value: "Hadas",
//         label: "Hadas Farhi"
//       },
//       {
//         value: "Netta",
//         label: "Netta Muller"
//       },
//       {
//         value: "Dor",
//         label: "Dor Yehuda"
//       }
//     ],
//     []
//   );

  async function addNewCandle() {
    // alert(document.getElementById("name").value + " has been added!");
    const payload = {
        "name": document.getElementById("name").value,
        "description": document.getElementById("description").value,
        "category": document.getElementById("category").value,
        "image_url": document.getElementById("image_url").value
    }
    // a POST request
    const response = await axios.post('http://localhost:8090', payload)
    console.log('status:', response.status)
    // fetch('http://localhost:8090', {
    //     method: 'POST',
    //     headers: {
    //         'Accept': 'application/json',
    //         'Content-Type': 'application/json',
    //         'Access-Control-Allow-Origin': '*'
    //     },
    //     body: JSON.stringify(payload)
    // })
    // .then(response => response.json())
    // .then(response => console.log(JSON.stringify(response)))
    history.push("/ManageCandlesDB")
  }

  const history = useHistory()
  const manageCandlesDB = () => {
    history.push("/ManageCandlesDB")
  }

  return (
    <>
      <Button className="Back" onClick={manageCandlesDB}>
        Back to Home
      </Button>
      <div className="App">
        <Flex gap={Flex.gaps.MEDIUM} direction={Flex.directions.COLUMN}>
          <div>
            <h1>Add New Candle</h1>
          </div>
          <div className="Text">
            <TextField id="name" placeholder="Name" title="Name" size={TextField.sizes.MEDIUM} requiredAsterisk={true} />
          </div>
          <div className="Text">
            <TextField id="description" placeholder="Description" title="Description" size={TextField.sizes.MEDIUM} requiredAsterisk={true} />
          </div>
          <div className="Text">
            <TextField id="category" placeholder="Category" title="Category" size={TextField.sizes.MEDIUM} requiredAsterisk={true} />
          </div>
          <div className="Text">
            <TextField id="image_url" placeholder="Image URL" title="Image URL" size={TextField.sizes.MEDIUM} requiredAsterisk={true} />
          </div>
          <div>
            <Button onClick={addNewCandle}>
              Add Candle
            </Button>
          </div>
        </Flex>
      </div>
    </>
  );
};

export default AddNewCandle;