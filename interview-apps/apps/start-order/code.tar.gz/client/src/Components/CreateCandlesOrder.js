import React from "react";
import { useState, useEffect, useMemo } from "react";
import ".././App.css";
import mondaySdk from "monday-sdk-js";
import "monday-ui-react-core/dist/main.css";
//Explore more Monday React Components here: https://style.monday.com/
// import AttentionBox from "monday-ui-react-core/dist/AttentionBox.js";
import { Flex, Dropdown, TextField, Button } from "monday-ui-react-core";
import { useHistory } from "react-router-dom";
import axios from "axios"

// Usage of mondaySDK example, for more information visit here: https://developer.monday.com/apps/docs/introduction-to-the-sdk/
const monday = mondaySdk();

const CreateCandlesOrder = () => {
  const [context, setContext] = useState();
  const options = useMemo(() => []);
  async function getCandles() {
    // const response = await fetch("http://localhost:8090")
    // console.log("LOGGER Status: " + response.status)
    // return response.json()
    // return fetch("http://localhost:8090")
    //   .then(async response => {
    //     return await response.json().then(response => ({ response }));
    //   })
    // ;

    return await fetch("http://localhost:8090")
  }
  getCandles()
    .then((response) => response.json())
    .then((candles) => {
      candles.forEach(candle => {
        options.push({value: candle['name'], label: candle['name']})
        console.log(candle)
      });
    });
  // const candles = getCandles()
  // console.log("Candles:", candles)


  // console.log(candles)
  // candles.forEach(candle => {
  //   options.push({value: candle, label: "test"})
  // });
  

  useEffect(() => {
    // Notice this method notifies the monday platform that user gains a first value in an app.
    // Read more about it here: https://developer.monday.com/apps/docs/mondayexecute#value-created-for-user/
    monday.execute("valueCreatedForUser");

    // TODO: set up event listeners, Here`s an example, read more here: https://developer.monday.com/apps/docs/mondaylisten/
    monday.listen("context", (res) => {
      setContext(res.data);
    });
  }, []);

  //Some example what you can do with context, read more here: https://developer.monday.com/apps/docs/mondayget#requesting-context-and-settings-data
  // const attentionBoxText = `Hello, your user_id is: ${
  //   context ? context.user.id : "still loading"
  // }.
  // Let's start building your amazing app, which will change the world!`;

  function onButtonClick() {
    alert("Candle Box Created for " + document.getElementById("firstName").value + "!");
  }

  const history = useHistory()
  const homepage = () => {
    history.push("/")
  }

  return (
    <>
      <Button className="Back" onClick={homepage}>
        Back to Home
      </Button>
      <div className="App">
        <Flex gap={Flex.gaps.MEDIUM} direction={Flex.directions.COLUMN}>
          <div>
            <h1>Create your Candle Gift Box</h1>
          </div>
          <div 
            // className="monday-storybook-text-field_column-wrapper"
            style={{
              width: "700px"
            }}
          >
            <Flex gap={Flex.gaps.SMALL}>
              <TextField id="firstName" placeholder="First Name" title="First Name" size={TextField.sizes.MEDIUM} requiredAsterisk={true} />
              <TextField placeholder="Last Name" title="Last Name" size={TextField.sizes.MEDIUM} requiredAsterisk={true} />
              <TextField placeholder="Quantity" title="Quantity" size={TextField.sizes.MEDIUM} requiredAsterisk={true} />
            </Flex>
          </div>
          <div 
            style={{
              width: "700px"
            }}
          >
            <Dropdown
              placeholder="Choose 3 Candles"
              // defaultValue={[options[0]]}
              options={options}
              multi
              className="dropdown-stories-styles_with-chips"
            />
          </div>
          <div>
            <Button onClick={onButtonClick}>
              Start Order
            </Button>
          </div>
        </Flex>
      </div>
    </>
  );
};

export default CreateCandlesOrder;
